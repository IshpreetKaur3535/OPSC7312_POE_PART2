package com.example.birdingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.opscpoe2_st10084595.UserData

import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.malkinfo.editingrecyclerview.view.UserAdapter
import java.util.*
import kotlin.collections.ArrayList

class AddingLocation : AppCompatActivity() {

    private lateinit var addsBtn: FloatingActionButton
    private lateinit var recv: RecyclerView
    private var userList = java.util.ArrayList<UserData>()
    private lateinit var userAdapter: UserAdapter
    private lateinit var searchView: SearchView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adding_location)


        /**set List*/
        userList = ArrayList()
        /**set find Id*/
        addsBtn = findViewById(R.id.addingBtn)
        recv = findViewById(R.id.mRecycler)
        /**set Adapter*/
        userAdapter = UserAdapter(this, userList)
        /**setRecycler view Adapter*/
        recv.layoutManager = LinearLayoutManager(this)
        recv.adapter = userAdapter
        searchView = findViewById(R.id.searchView)


        /**set Dialog*/
        addsBtn.setOnClickListener { addInfo() }


        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }

        })





    }

    private fun addInfo() {
        val inflater = LayoutInflater.from(this)
        val v = inflater.inflate(R.layout.add_item,null)
        /**set view*/
        val birdName = v.findViewById<EditText>(R.id.birdNameEdTxt)
        val userName = v.findViewById<EditText>(R.id.userName)
        val userNo = v.findViewById<EditText>(R.id.userNo)
        val userNo2 = v.findViewById<EditText>(R.id.userNo2)

        val addDialog = AlertDialog.Builder(this)

        addDialog.setView(v)
        addDialog.setPositiveButton("Ok"){
                dialog,_->
            val BirdName = birdName.text.toString()
            val Address = userName.text.toString()
            val latitude = userNo.text.toString()
            val longitude = userNo2.text.toString()
            userList.add(UserData("Bird Name: $BirdName","Address: $Address","Latitude: $latitude", "Longitude: $longitude"))
            userAdapter.notifyDataSetChanged()
            Toast.makeText(this,"Adding Location Successful", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        addDialog.setNegativeButton("Cancel"){
                dialog,_->
            dialog.dismiss()
            Toast.makeText(this,"Cancel", Toast.LENGTH_SHORT).show()

        }
        addDialog.create()
        addDialog.show()
    }



    private fun filterList(query: String?) {

        if (query != null) {
            val filteredList = ArrayList<UserData>()
            for (i in userList) {
                if (i.birdName.uppercase(Locale.ROOT).contains(query)) {
                    filteredList.add(i)
                }
            }

            if (filteredList.isEmpty()) {
                Toast.makeText(this, "No Data found", Toast.LENGTH_SHORT).show()
            } else {
                userAdapter.setFilteredList(filteredList)
            }
        }
    }




}