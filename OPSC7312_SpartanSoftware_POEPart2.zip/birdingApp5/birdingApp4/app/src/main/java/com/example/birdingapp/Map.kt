package com.example.birdingapp

import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Rect
import android.location.GpsStatus
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat

import org.osmdroid.config.Configuration.getInstance
import org.osmdroid.api.IMapController
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.IMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import android.Manifest
import android.app.AlertDialog
import android.content.SharedPreferences
import android.location.Location
import android.telephony.SmsManager
import com.example.birdingapp.databinding.ActivityMapBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.bonuspack.routing.OSRMRoadManager
import org.osmdroid.bonuspack.routing.Road
import org.osmdroid.bonuspack.routing.RoadManager
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer


class Map : AppCompatActivity(), IMyLocationProvider, MapListener, GpsStatus.Listener {

    // variables
    private val LOCATION_REQUEST_CODE = 100
    //private val binding: ActivityMainBinding by lazy{
    //  ActivityMainBinding.inflate(layoutInflater)
    //}
    private val noteMap = HashMap<GeoPoint, String>()
    private lateinit var mapView: MapView
    private lateinit var mapController: IMapController
    private lateinit var mMyLocationNewOverlay: MyLocationNewOverlay
    private lateinit var controller: IMapController

    // declare global varibles for latitude and lagitude
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0

    // Add these 2 variables as global variables in Map.kt:

    private var distanceUnit: String = "KM"
    private var maxDistance: Int = 5 // Default max distance


    val hotspotLocation = listOf(
        Pair("Hluhluwe iMfolozi Park", GeoPoint(-28.219831, 31.951865)),
        Pair("Umgeni River Bird Park", GeoPoint(-29.808167, 31.017467)),
        Pair("Durban Japanese Gardens", GeoPoint(-29.7999, 31.03758))

    )

    private val hotspotMarkers = mutableListOf<Marker>() // Initialize an empty list for hotspot markers

    // user settings var
    private lateinit var unitPreference: SharedPreferences
    private lateinit var maxDistancePreference: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val sendSmsButton = findViewById<Button>(R.id.sendLocationButton)

        //Inside your onCreate Method
        //val phoneNumberEditText = findViewById<EditText>(R.id.phoneNumberEditText)

        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences("Open Street Map Android", MODE_PRIVATE)
        )
        // settings
        unitPreference = PreferenceManager.getDefaultSharedPreferences(this)
        maxDistancePreference = PreferenceManager.getDefaultSharedPreferences(this)

        // map
        mapView = binding.mapView
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.mapCenter
        mapView.setMultiTouchControls(true)
        mapView.getLocalVisibleRect(Rect())

        mMyLocationNewOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), mapView)
        controller = mapView.controller
        mMyLocationNewOverlay.enableMyLocation()
        mMyLocationNewOverlay.enableFollowLocation()
        mMyLocationNewOverlay.isDrawAccuracyEnabled = true


        // set the initial zoom level
        controller.setZoom(6.0)

        mapView.overlays.add(mMyLocationNewOverlay)
        setupMap() // ths function adds the marker fot the start point
        mapView.addMapListener(this)

        //check and request location permission
        managePermissions()

        // Create a custom overlay for the animated marker
        val animatedMarkerOverlay = object : Overlay(this){
            override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
                //calculate the longitude and latitude from the GeoPint
                val geoPoint = mMyLocationNewOverlay.myLocation
                latitude = geoPoint.latitude
                longitude = geoPoint.longitude

                //create a cuatom dialog or info window to display the latitude and longitude
                val dialog = Dialog(this@Map)
                dialog.setContentView(R.layout.custom)


                val latitudeTextView = dialog.findViewById<TextView>(R.id.latitudeTextView)
                val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

                latitudeTextView.text = "Latitude: $latitude"
                longitudeTextView.text = "Longitude: $longitude"

                dialog.show()
                return true
            }
        }
        //add the animatedMarlerOverlay to the map
        mapView.overlays.add(animatedMarkerOverlay)
        //Get reference to the "View Hotspots" button
        val viewHotspotsButton = findViewById<Button>(R.id.viewHotspotsButton)

        //add an onClickListener to the button
        viewHotspotsButton.setOnClickListener{
            addHotspotMarkers()
        }

        // show routes button
        val showRoutesButton = findViewById<Button>(R.id.showRoutesButton)
        showRoutesButton.setOnClickListener {
            calculateAndDisplayRoutes()
        }

        sendSmsButton.setOnClickListener{
            // Check if the location information is available
            if (latitude != 0.0 && longitude != 0.0) {
                val dialogBuilder = AlertDialog.Builder(this)
                val inflater = layoutInflater
                val dialogView = inflater.inflate(R.layout.phone_number_dialog, null)
                val phoneNumberEditText = dialogView.findViewById<EditText>(R.id.phoneNumberEditText)

                dialogBuilder.setView(dialogView)
                dialogBuilder.setTitle("Enter Phone Number")

                dialogBuilder.setPositiveButton("Send") { dialog, which ->
                    val phoneNumber = phoneNumberEditText.text.toString().trim()

                    if (phoneNumber.isNotEmpty()) {
                        val message = "Latitude: $latitude, Longitude: $longitude"
                        // Call the sendSMS function to send the SMS
                        sendSMS(phoneNumber, message)
                    } else {
                        Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
                    }
                }

                dialogBuilder.setNegativeButton("Cancel") { dialog, which ->
                    dialog.dismiss()
                }

                val dialog = dialogBuilder.create()
                dialog.show()
            } else {
                Toast.makeText(this, "Location information is not available", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun calculateAndDisplayRoutes() {
        val startPoint = mMyLocationNewOverlay.myLocation

        if (startPoint == null)
        {
            Toast.makeText(this, "Location loading error", Toast.LENGTH_SHORT).show()
            return
        }

        for ((startLocationName, endPoint) in hotspotLocation){
            GlobalScope.launch(Dispatchers.IO) {
                val roadManager = OSRMRoadManager(this@Map, "OBP_Toto/1.0")
                var road: Road? = null
                var retryCount = 0

                while (road == null && retryCount < 3) {
                    road = try{
                        roadManager.getRoad(arrayListOf(startPoint,endPoint))
                    }catch (e: Exception) {
                        null
                    }
                    retryCount++
                }
                withContext(Dispatchers.Main) {
                    if (road != null && road.mStatus == Road.STATUS_OK) {
                        val radOverlay = RoadManager.buildRoadOverlay(road)
                        mapView.overlays.add(radOverlay)

                        val unit = unitPreference.getString("unit", "KM")

                        if (unit == "KM")
                        {
                            //display the route details in an alert dialog
                            val routeDetails = "Start Location: Your Current Location\nEnd Location: $startLocationName\nDistance: ${road.mLength} $unit"
                            showRouteDetailsDialog(routeDetails)
                        }
                        else
                        {
                            //display the route details in an alert dialog
                            val routeDetails = "Start Location: Your Current Location\nEnd Location: $startLocationName\nDistance: ${road.mLength*0.621371} $unit"
                            showRouteDetailsDialog(routeDetails)
                        }

                        mapView.invalidate()
                    }else {
                        Toast.makeText(this@Map, "Error when loading road - status=${road?.mStatus ?: "unknown"}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun showRouteDetailsDialog(routeDetails: String)
    {
        runOnUiThread{
            val alertDialog = AlertDialog.Builder(this@Map)
            alertDialog.setTitle("Route Details")
            alertDialog.setMessage(routeDetails)
            alertDialog.setPositiveButton("OK") {dialog, _ ->
                dialog.dismiss()
            }
            alertDialog.create().show()
        }
    }

    private fun setupMap()
    {
        Configuration.getInstance().load(this,
            PreferenceManager.getDefaultSharedPreferences(this))
        // mapView = binding.mapView
        mapController = mapView.controller
        mapView.setMultiTouchControls(true)

        //Initialize the map with a start point
        val startPoint = GeoPoint(-29.8587, 31.0218)
        mapController.setCenter(startPoint)
        mapController.setZoom(6.0)

        //Create a marker for the start point (ic)
        val marker = Marker(mapView)
        marker.position = startPoint
        marker.icon = ResourcesCompat.getDrawable(resources,R.drawable.baseline_add_location_24, null)


        // add a click listener to the marker
        marker.setOnMarkerClickListener { marker, mapView ->
            val latitude = marker.position.latitude
            val logitude = marker.position.longitude

            val dialog = Dialog(this@Map)
            dialog.setContentView(R.layout.custom)


            val latitudeTextView = dialog.findViewById<TextView>(R.id.latitudeTextView)
            val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

            latitudeTextView.text = "Latitude: $latitude"
            longitudeTextView.text = "Longitude: $logitude"

            dialog.show()

            true
        }

        mapView.overlays.add(marker)
    }

    private fun addHotspotMarkers(){
        // Clear any existing hotspot markers from the map
        mapView.overlays.removeAll(hotspotMarkers)

        val unit = unitPreference.getString("unit", "KM")
        val maxDistance = maxDistancePreference.getString("maxDistance", "300")

        Toast.makeText(this, "Max distance: $maxDistance $unit", Toast.LENGTH_SHORT).show()

        for((name, location) in hotspotLocation)
        {
            val marker = Marker(mapView)
            marker.position = location
            //marker.title = name
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            marker.icon = ResourcesCompat.getDrawable(resources, R.drawable.baseline_location_on_24, null)

            //Create a custom dialog for displaying location name and adding a note
            marker.setOnMarkerClickListener{marker, mapView1 ->
                val dialog = Dialog(this@Map)
                dialog.setContentView(R.layout.custom_marker_dialog)

                val noteEditText = dialog.findViewById<EditText>(R.id.noteEditText)
                val saveNoteButton = dialog.findViewById<Button>(R.id.saveNoteButton)
                val displayNoteTextView = dialog.findViewById<TextView>(R.id.displayNoteTextView)

                // Display the location name
                val locationNameTextView = dialog.findViewById<TextView>(R.id.locationNameTextView)
                locationNameTextView.text = name

                //Load and displat the saved note for this marker
                val savedNote = loadNote(marker.position)
                displayNoteTextView.text = savedNote

                saveNoteButton.setOnClickListener {
                    val note = noteEditText.text.toString()
                    saveNote(marker.position, note)
                    displayNoteTextView.text = note
                }

                dialog.show()
                true

            }
            hotspotMarkers.add(marker) // add the marker to the list
        }


        // add the new hotspot marker to the map
        mapView.overlays.addAll(hotspotMarkers)
        mapView.invalidate() // refresh the map to display the new markers

    }

    private fun saveNote(location: GeoPoint, note: String) {
        // store the note in the HashMap with the location as the key
        noteMap[location] = note
    }

    private fun loadNote(location: GeoPoint): String {
        //Retrieve the note from the HashMap based on the location

        return noteMap[location] ?: ""
    }


    private fun isLocationPermissionGranted():Boolean
    {
        val fineLocation = ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        val coarseLocation = ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        return fineLocation && coarseLocation
    }

    // ctrl + o to implement the overrirde methods
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode == LOCATION_REQUEST_CODE)
        {
            if (grantResults.isNotEmpty())
            {
                for(result in grantResults)
                {
                    if(result == PackageManager.PERMISSION_GRANTED)
                    {
                        //Handle permission granted
                        // you can re-initilize the map here if needed
                        // setupMap()

                    }else {
                        Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }// end of on requestpermission method

    private fun sendSMS(destinationPhoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(destinationPhoneNumber, null, message, null, null)
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show()
        }catch (e: Exception){
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }
    private fun managePermissions()
    {
        val requestPermission = mutableListOf<String>()
        if(!isLocationPermissionGranted())
        {
            // if these were granted
            requestPermission.add(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermission.add(Manifest.permission.ACCESS_COARSE_LOCATION)

        }

        if(!isSmsPermissionGranted()){
            requestPermission.add(Manifest.permission.SEND_SMS)
        }

        if(requestPermission.isNotEmpty())
        {
            ActivityCompat.requestPermissions(this,requestPermission.toTypedArray(),LOCATION_REQUEST_CODE)

        }
    }

    private fun isSmsPermissionGranted():Boolean{
        return ActivityCompat.checkSelfPermission(
            this, android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun startLocationProvider(myLocationConsumer: IMyLocationConsumer?): Boolean {
        return true
    }

    override fun stopLocationProvider() {
        TODO("Not yet implemented")
    }

    override fun getLastKnownLocation(): Location {
        return Location("last_known_location")
    }

    override fun destroy() {
        TODO("Not yet implemented")
    }

    override fun onScroll(event: ScrollEvent?): Boolean{
        return true
    }

    override fun onZoom(event: ZoomEvent?): Boolean {
        return false
    }

    override fun onGpsStatusChanged(p0: Int) {
        TODO("Not yet implemented")
    }
}