package com.example.birdingapp

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast

class Settings : AppCompatActivity() {

    // var
    private lateinit var unitPreference: SharedPreferences
    private lateinit var maxDistancePreference: SharedPreferences

    private lateinit var kmRadio: RadioButton
    private lateinit var mRadio: RadioButton
    private lateinit var maxDistanceEditText: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        unitPreference = PreferenceManager.getDefaultSharedPreferences(this)
        maxDistancePreference = PreferenceManager.getDefaultSharedPreferences(this)

        // typecast var
        kmRadio = findViewById(R.id.kmRadioButton)
        mRadio = findViewById(R.id.mRadioButton)
        maxDistanceEditText = findViewById(R.id.editTextMaxDistance)
        saveButton = findViewById(R.id.btnSave)

        // set button click event
        saveButton.setOnClickListener {
            val unit = if (kmRadio.isChecked) "KM" else "M"
            val maxDistance = maxDistanceEditText.text.toString()
            saveSettings(unit, maxDistance)
        }
    }

    // this method saves the users preferred unit of length and max distance for viewing hotspots
    private fun saveSettings(unit: String, maxDistance: String) {
        val editorUnit = unitPreference.edit()
        val editorMaxDistance = maxDistancePreference.edit()

        editorUnit.putString("unit", unit)
        editorMaxDistance.putString("maxDistance", maxDistance)

        editorUnit.apply()
        editorMaxDistance.apply()

        Toast.makeText(this, "Settings saved successfully.", Toast.LENGTH_SHORT).show()
    }
}