package com.example.opscpoe2_st10084595

data class UserData (
    var birdName: String,
    var address:String,
    var userMb:String,
    var userMb2:String
)