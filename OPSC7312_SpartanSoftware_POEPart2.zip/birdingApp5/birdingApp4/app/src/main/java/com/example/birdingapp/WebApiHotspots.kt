package com.example.birdingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class WebApiHotspots : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_api_hotspots)

        //variable
        val webView = findViewById<WebView>(R.id.webView)
        webView.webViewClient = WebViewClient()
        val url = "https://ebird.org/hotspots"
        webView.loadUrl(url)
    }
}