package com.example.opscpoe2_st10084595



data class LanguageData (
    var title: String

)

