package com.example.birdingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {
    private lateinit var edUsername: EditText

    private lateinit var edPassword: EditText

    private lateinit var btnLogin: Button

    private lateinit var mAuth: FirebaseAuth

    var btnReg: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContentView(R.layout.activity_login)
        edUsername = findViewById(R.id.loginEmail)

        edPassword = findViewById(R.id.loginPassword)

        btnLogin = findViewById(R.id.btnLogin)

        btnReg = findViewById(R.id.btnRegister)

        mAuth = FirebaseAuth.getInstance()

        btnLogin.setOnClickListener {

            loginUser()

        }
    }
    private fun loginUser() {

        try {

            val email = edUsername.text.toString().trim()

            val password = edPassword.text.toString().trim()



            if (TextUtils.isEmpty(email)) {

                Toast.makeText(this, "Please enter an email address!", Toast.LENGTH_SHORT).show()

                edUsername.requestFocus()

                return

            }

            if (TextUtils.isEmpty(password)) {

                Toast.makeText(this, "Please enter a password!", Toast.LENGTH_SHORT).show()

                edPassword.requestFocus()

                return

            }



            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->

                if (task.isSuccessful) {

                    Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()

                    edUsername.setText("")

                    edPassword.setText("")

                    edUsername.requestFocus()

                    // take user to next page

                    val intent = Intent(this, MainActivity::class.java)

                    startActivity(intent)

                } else {

                    Toast.makeText(this, "Login Unsuccessful! Please try again.", Toast.LENGTH_SHORT).show()

                    edUsername.setText("")

                    edPassword.setText("")

                    edUsername.requestFocus()

                }

            }

        } catch (eer: Exception) {

            Toast.makeText(this, "Error Occurred: " + eer.message, Toast.LENGTH_SHORT).show()

        }

    }// ends login



    fun regBtn (view: View)
    {
        val intent = Intent(this, Register::class.java)
        startActivity(intent)
    }
}