Pheriphas App
*************************************************************************************************************************************************************
Developed by Spartan Software (Ishpreet Kaur, Kaydn Naidoo, Tyreece Pillay)
*************************************************************************************************************************************************************
Version 2.0
*************************************************************************************************************************************************************
Plugins
--------------------------------------------------------------------------------
   -- id 'com.android.application'
   -- id 'org.jetbrains.kotlin.android'
   -- id 'com.google.gms.google-services'
--------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Dependencies
--------------------------------------------------------------------------------------------
To get the mapping working in the app the following dependencies has been added to the project
	-- implementation 'org.osmdroid:osmdroid-android:6.1.16'
	-- implementation 'com.google.android.gms:play-services-location:21.0.1'
	-- implementation 'com.github.MKergall:osmbonuspack:6.9.0'
	--implementation 'com.google.code.gson:gson:2.8.9'
	-- In the setting.gradle file add the maven -> maven { url "https://jitpack.io" }
--------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Software Requirement
-------------------------------------------------------------------------------
   --Operating System: Windows 10(32 or 64 bit version), Windows11
   --Processor: Any processor would work
   --RAM: Min 8GB  
-------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Software specs
--------------------------------------------------------------------------------
  --Android Studio Electric Eel|2022.1.1
  	->Navigation Drawer Activity
  	->Language: Kotlin
	->Minimum SDK: API 27: Android 8.1 (Oreo)
  --Online Firebase Database
--------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Project Description
---------------------------------------------------------------------------------------------------------------------------------
The program used android studio to create the prototype of the Pheriphas app. The app allows users to login and register to the 
app. Allows user display the birding hotspost on the map and using the online web api which shows the birding hotspot on the ebird 
website. Also shows the current location on the map and user can also get the visually displayed route to the hotspost location from 
their current location. The app also has a option for a user to send the location via sms. The app allows user to save and view the 
bird observations. Lastly the app also has a option for a user to change the setting accroding to the user preference.
 
--------------------------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
How To Use the app
---------------------------------------------------------------------------------------------------------------------------------
When the app runs the first screen the user will view is the spalsh Screen with a progress bar showing the app is loading. Once 
the app is loaded the user will then view the welcome screen.

	--Login Screen
	  On this screen the user will see the field for an username and one for a password. The user must enter in these fields
	  in order to log in to the app. Once the user finish entering in the field, the user must click on the login button to 
          log in to the app. If the user do not have an account they must create one by clicking on the signup button which will 
          redirect user to the signup screen of the app.
	
	--Signup screen
	  On this screen the user has to enter in their username, password and confirm passoword in order to signup to the app.
          Once the user is finished entering in the fields they must click on the signup button, if the user is signed up to the
	  app succesfully the signup button will direct user to the login screen, if not will get an error message. If the user 
	  already have an account they can click on the login button which will direct user to the login screen.
 
	--Once the user is successfully logged in the app they user will see the home screen of the app. On the left side of the
          screen the user will view the three horizontal line, the user must click on it and it will show the navigation bar which
	  has the activities that the user can do in the app.
	
	--The attached demo video will show each and every step on how to navigate thorugh the screen.
--------------------------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Features
---------------------------------------------------------------------------------------------------------------
   --User input with exception handling
   --Makes use of good comments to follow and guide through the program
   --Makes use of graphical interface 
   --The program makes use of colour changes for easy navigation in the graphical pages 
   --This Program is all in all, user friendly and if the user reads all prompts everything
     will run smoothly, if not the program will redirect the user on the right path.
   --Make use of a splash screen to show the app is loading.
--------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Installations instructions and Instructions on How to use the application
--------------------------------------------------------------------------------------------------------------------
If you don not have android studio installed, follow the following steps to use the app.
   --Unzip the folder: OPSC7312_SpartanS_POEPart2  
   --Then Open the folder and Copy the attached apk file -> app-debug and tranfer it to the android phone
   --Install the app on the phone and it will be ready to use.
   --Make sure the phone you using the APK version is 27 or higher otherwise the app will not run.

--------------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Troubleshooting
--------------------------------------------------------------------------------------------------------------------------------------
   --Make sure that you place the folder in the androidStudioProject folder if you want to see the code or to run the app on the emulator.

   --When the user runs the app on the emulator and the errors occurs saying can not install the app, make sure when you run the app you
     wipe the emulators data first. You can do that by simply clicking on the three dots next to the device and it will give option you must 
     choose wipe data. Also make sure when you are wiping the data the emulator in stopped.

   --Before runnin the app on the emulator the user must clean the project first that way it takes less space. To do that user must click on
     the build option at the top of the screen and choose the option clean project.

   --When running the app the map is not appearing. Make sure the dependencies has been added for the map in the build.gradle(module:app). 
     The dependency for a map to add has been given under the dependencies heading in this document. Also make sure that you have good internet
     connection.

--------------------------------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
FAQs
----------------------------------------------------------------------------------------------------------------
  --Q1: What happens if we input the wrong input for the numerical values?
        If you input the string values in the numerical inputs the app will not accept the values and will encourage 
        enter int he value again without crashing the app.

  --Q2: Does it save the data somewhere?
        Yes it does save user signup data in firebase database.

  --Q3: How must I send location on SMS?
        On the View Map page click on the send location button whihc will give then opens ups the dialog box. The user must 
        enter in their correct cell phone number and then click on the send button. By doing this the user will get the
	location on sms.
  
  --Q4: How to get the route displayed visually?
        Make sure that the user click on one of the hotspot provided and then click on the show route button which will
 	the show the route visually on the map
-------------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Developer contact info 
--------------------------------------------------------------------------------
   --Name: Ishpreet Kaur
   --Student number: ST10084227
   --Email ID: ST10084227@vcconnect.edu.za
   --Cell number: +27791936637

   --Name: Kaydn Naidoo
   --Student number: ST10084595
   --Email ID: ST10084595@vcconnect.edu.za
   
   --Name: Tyreece Pillay
   --Student number: ST10084621
   --Email ID: ST10084621@vcconnect.edu.za
   
	
--------------------------------------------------------------------------------
***************************************************************************************************************************************************************
Code Attribution
----------------------------------------------------------------------------------------------------------------------------------------------------
-Phonesandmore. Samsung Galaxy A72: How to enable the Developer Options? for USB Debugging etc. Available at: https://www.youtube.com/watch?v=IQDLKNoPccY.
 [Accessed 5 June 2023]

-Kachhadiya, C. Android Recycler View With Multiple View Types | Android Studio | Java. Available at: https://www.youtube.com/watch?            
 v=GwK1Y_4cQWc. [Accessed 13 October 2023]

	
-Coding Adventure. CardView UI Design Android Studio | Using Grid Layout. Available at: 
	  https://www.youtube.com/watch?v=YKssd_9x8Eg. [Accessed 14 October 2023]

-Indently. (Kotlin 2020) How to create a Horizontal Progress Bar in Android Studio. Available at: https://www.youtube.com/watch?v=xU-Cc41DfTg. 
 [Accessed 6 June 2023]
 
-Logo: I created the logo in paint
-----------------------------------------------------------------------------------------------------------------------------------------------------
**************************************************************************************************************************************************************
Default Login Info
---------------------------------------------------
	-Username: text@gmail.com
	-Password: 12345@
---------------------------------------------------
