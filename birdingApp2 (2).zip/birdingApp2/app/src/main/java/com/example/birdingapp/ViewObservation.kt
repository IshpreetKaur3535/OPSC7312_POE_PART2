package com.example.birdingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ViewObservation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_observation)
    }
}