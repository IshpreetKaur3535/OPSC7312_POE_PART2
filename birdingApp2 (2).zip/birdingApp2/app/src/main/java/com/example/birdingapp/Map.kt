package com.example.birdingapp



import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Rect
import android.location.GpsStatus
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat

import org.osmdroid.config.Configuration.getInstance
import org.osmdroid.api.IMapController
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.IMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import android.Manifest
import android.location.Location
import android.telephony.SmsManager
import com.example.birdingapp.databinding.ActivityMapBinding
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer

class Map : AppCompatActivity(), IMyLocationProvider, MapListener, GpsStatus.Listener {

    // variables
    private val LOCATION_REQUEST_CODE = 100
    //private val binding: ActivityMainBinding by lazy{
    //  ActivityMainBinding.inflate(layoutInflater)
    //}

    private lateinit var mapView: MapView
    private lateinit var mapController: IMapController
    private lateinit var mMyLocationNewOverlay: MyLocationNewOverlay
    private lateinit var controller: IMapController

    // declare global varibles for latitude and lagitude
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0

    val hotspotLocation = listOf(
        Pair("Hluhluwe iMfolozi Park", GeoPoint(-28.219831, 31.951865)),
        Pair("Umgeni River Bird Park", GeoPoint(-29.808167, 31.017467)),
        Pair("Durban Japanese Gardens", GeoPoint(-29.7999, 31.03758))

    )

    private val hotspotMarkers = mutableListOf<Marker>() // Initialize an empty list for hotspot markers

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val sendSmsButton = findViewById<Button>(R.id.sendLocationButton)

        //Inside your onCreate Method
        val phoneNumberEditText = findViewById<EditText>(R.id.phoneNumberEditText)

        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences("Open Street Map Android", MODE_PRIVATE)
        )

        mapView = binding.mapView
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.mapCenter
        mapView.setMultiTouchControls(true)
        mapView.getLocalVisibleRect(Rect())

        mMyLocationNewOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), mapView)
        controller = mapView.controller
        mMyLocationNewOverlay.enableMyLocation()
        mMyLocationNewOverlay.enableFollowLocation()
        mMyLocationNewOverlay.isDrawAccuracyEnabled = true


        // set the initial zoom level
        controller.setZoom(6.0)

        mapView.overlays.add(mMyLocationNewOverlay)
        setupMap() // ths function adds the marker fot the start point
        mapView.addMapListener(this)

        //check and request location permission
        managePermissions()

        // Create a custom overlay for the animated marker
        val animatedMarkerOverlay = object : Overlay(this){
            override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
                //calculate the longitude and latitude from the GeoPint
                val geoPoint = mMyLocationNewOverlay.myLocation
                latitude = geoPoint.latitude
                longitude = geoPoint.longitude

                //create a cuatom dialog or info window to display the latitude and longitude
                val dialog = Dialog(this@Map)
                dialog.setContentView(R.layout.custom)


                val latitudeTextView = dialog.findViewById<TextView>(R.id.latitudeTextView)
                val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

                latitudeTextView.text = "Latitude: $latitude"
                longitudeTextView.text = "Longitude: $longitude"

                dialog.show()
                return true
            }
        }
        //add the animatedMarlerOverlay to the map
        mapView.overlays.add(animatedMarkerOverlay)
        //Get reference to the "View Hotspots" button
        val viewHotspotsButton = findViewById<Button>(R.id.viewHotspotsButton)

        //add an onClickListener to the button
        viewHotspotsButton.setOnClickListener{
            addHotspotMarkers()
        }

        sendSmsButton.setOnClickListener{
            //check if the location information is available
            if(latitude != 0.0 && longitude != 0.0){
                //get the phone number from the EditText
                val phoneNumber = phoneNumberEditText.text.toString().trim()

                // Checks if the phone number is not empty
                if(phoneNumber.isNotEmpty())
                {
                    val message = "Latitude: $latitude, Longitude: $longitude"
                    //call the sendSms function to send the SMS
                    sendSMS(phoneNumber, message)

                }else{
                    Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
                }
            }else {
                Toast.makeText(this, "Location information is not available", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun setupMap()
    {
        Configuration.getInstance().load(this,
            PreferenceManager.getDefaultSharedPreferences(this))
        // mapView = binding.mapView
        mapController = mapView.controller
        mapView.setMultiTouchControls(true)

        //Initialize the map with a start point
        val startPoint = GeoPoint(-29.8587, 31.0218)
        mapController.setCenter(startPoint)
        mapController.setZoom(6.0)

        //Create a marker for the start point (ic)
        val marker = Marker(mapView)
        marker.position = startPoint
        marker.icon = ResourcesCompat.getDrawable(resources,R.drawable.baseline_add_location_24, null)


        // add a click listener to the marker
        marker.setOnMarkerClickListener { marker, mapView ->
            val latitude = marker.position.latitude
            val logitude = marker.position.longitude

            val dialog = Dialog(this@Map)
            dialog.setContentView(R.layout.custom)


            val latitudeTextView = dialog.findViewById<TextView>(R.id.latitudeTextView)
            val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

            latitudeTextView.text = "Latitude: $latitude"
            longitudeTextView.text = "Longitude: $logitude"

            dialog.show()

            true
        }

        mapView.overlays.add(marker)
    }

    private fun addHotspotMarkers(){
        // Clear any existing hotspot markers from the map
        mapView.overlays.removeAll(hotspotMarkers)

        for((name, location) in hotspotLocation)
        {
            val marker = Marker(mapView)
            marker.position = location
            marker.title = name
            hotspotMarkers.add(marker) // add the marker to the list
        }

        // add the new hotspot marker to the map
        mapView.overlays.addAll(hotspotMarkers)
        mapView.invalidate() // refresh the map to display the new markers

    }

    private fun isLocationPermissionGranted():Boolean
    {
        val fineLocation = ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        val coarseLocation = ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        return fineLocation && coarseLocation
    }

    // ctrl + o to implement the overrirde methods
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode == LOCATION_REQUEST_CODE)
        {
            if (grantResults.isNotEmpty())
            {
                for(result in grantResults)
                {
                    if(result == PackageManager.PERMISSION_GRANTED)
                    {
                        //Handle permission granted
                        // you can re-initilize the map here if needed
                        // setupMap()

                    }else {
                        Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }// end of on requestpermission method

    private fun sendSMS(destinationPhoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(destinationPhoneNumber, null, message, null, null)
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show()
        }catch (e: Exception){
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }
    private fun managePermissions()
    {
        val requestPermission = mutableListOf<String>()
        if(!isLocationPermissionGranted())
        {
            // if these were granted
            requestPermission.add(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermission.add(Manifest.permission.ACCESS_COARSE_LOCATION)

        }

        if(!isSmsPermissionGranted()){
            requestPermission.add(Manifest.permission.SEND_SMS)
        }

        if(requestPermission.isNotEmpty())
        {
            ActivityCompat.requestPermissions(this,requestPermission.toTypedArray(),LOCATION_REQUEST_CODE)

        }
    }

    private fun isSmsPermissionGranted():Boolean{
        return ActivityCompat.checkSelfPermission(
            this, android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun startLocationProvider(myLocationConsumer: IMyLocationConsumer?): Boolean {
        return true
    }

    override fun stopLocationProvider() {
        TODO("Not yet implemented")
    }

    override fun getLastKnownLocation(): Location {
        return Location("last_known_location")
    }

    override fun destroy() {
        TODO("Not yet implemented")
    }

    override fun onScroll(event: ScrollEvent?): Boolean{
        return true
    }

    override fun onZoom(event: ZoomEvent?): Boolean {
        return false
    }

    override fun onGpsStatusChanged(p0: Int) {
        TODO("Not yet implemented")
    }
}